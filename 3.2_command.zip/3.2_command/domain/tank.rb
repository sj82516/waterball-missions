class Tank
  def move_forward
    pp 'The tank has moved forward.'
  end

  def move_backward
    pp 'The tank has moved backward.'
  end
end
