
class Telecom
  def connect
    pp 'The telecom has been turned on.'
  end

  def disconnect
    pp 'The telecom has been turned off.'
  end
end
